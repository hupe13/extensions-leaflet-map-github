# Leaflet Plugins

<h4>leaflet.zoomhome</h4>
https://github.com/torfsen/leaflet.zoomhome

Verwendet von <pre>[zoomhomemap]</pre>
