Files from https://github.com/torfsen/leaflet.zoomhome
